from flask import Flask, request, jsonify
from datetime import datetime

app = Flask(__name__)

@app.route("/")
def home():
    return "Age Calculator API Running"

@app.route("/calculate_age")
def calculate_age():
    dob = request.args.get("dob")  # Format: YYYY-MM-DD

    birth_date = datetime.strptime(dob, "%Y-%m-%d")
    today = datetime.today()

    age = today.year - birth_date.year - (
        (today.month, today.day) < (birth_date.month, birth_date.day)
    )

    return jsonify({
        "date_of_birth": dob,
        "age": age
    })

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)